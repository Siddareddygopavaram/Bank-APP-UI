import React from "react";
import "./Header.scss";

const HeaderPage = () => {
  return (
    <>
      <div className="Header-contianer">
        <h1>
          One<span>Bank</span><b> App</b>
        </h1>
      </div>
    </>
  );
};

export default HeaderPage;
